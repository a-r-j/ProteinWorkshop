###########################################################################################
# Radial basis and cutoff
# Authors: Ilyes Batatia, Gregor Simm
# This program is distributed under the MIT License (see MIT.md)
###########################################################################################

import numpy as np
import torch
from beartype import beartype as typechecker
from jaxtyping import Float, jaxtyped


class BesselBasis(torch.nn.Module):
    """
    Klicpera, J.; Groß, J.; Günnemann, S. Directional Message Passing for Molecular Graphs; ICLR 2020.
    Equation (7)
    """

    def __init__(
        self, r_max: float, num_basis: int = 8, trainable: bool = False
    ):
        super().__init__()

        bessel_weights = (
            np.pi
            / r_max
            * torch.linspace(
                start=1.0,
                end=num_basis,
                steps=num_basis,
                dtype=torch.get_default_dtype(),
            )
        )
        if trainable:
            self.bessel_weights = torch.nn.Parameter(bessel_weights)
        else:
            self.register_buffer("bessel_weights", bessel_weights)

        self.register_buffer(
            "r_max", torch.tensor(r_max, dtype=torch.get_default_dtype())
        )
        self.register_buffer(
            "prefactor",
            torch.tensor(
                np.sqrt(2.0 / r_max), dtype=torch.get_default_dtype()
            ),
        )

    def forward(
        self,
        x: torch.Tensor,
    ) -> torch.Tensor:  # [..., 1]
        numerator = torch.sin(self.bessel_weights * x)  # [..., num_basis]
        return self.prefactor * (numerator / x)

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(r_max={self.r_max}, num_basis={len(self.bessel_weights)}, "
            f"trainable={self.bessel_weights.requires_grad})"
        )


class PolynomialCutoff(torch.nn.Module):
    """
    Klicpera, J.; Groß, J.; Günnemann, S. Directional Message Passing for Molecular Graphs; ICLR 2020.
    Equation (8)
    """

    p: torch.Tensor
    r_max: torch.Tensor

    def __init__(self, r_max: float, p: int = 6):
        super().__init__()
        self.register_buffer(
            "p", torch.tensor(p, dtype=torch.get_default_dtype())
        )
        self.register_buffer(
            "r_max", torch.tensor(r_max, dtype=torch.get_default_dtype())
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # yapf: disable
        envelope = (
                1.0
                - ((self.p + 1.0) * (self.p + 2.0) / 2.0) * torch.pow(x / self.r_max, self.p)
                + self.p * (self.p + 2.0) * torch.pow(x / self.r_max, self.p + 1)
                - (self.p * (self.p + 1.0) / 2) * torch.pow(x / self.r_max, self.p + 2)
        )
        # yapf: enable

        # noinspection PyUnresolvedReferences
        return envelope * (x < self.r_max).type(torch.get_default_dtype())

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(p={self.p}, r_max={self.r_max})"


@jaxtyped(typechecker=typechecker)
def compute_rbf(
    distances: Float[torch.Tensor, " num_edges"],
    min_distance: float = 0.0,
    max_distance: float = 10.0,
    num_rbf: int = 8,
) -> Float[torch.Tensor, "num_edges num_rbf"]:
    """
    Adapted from https://github.com/jingraham/neurips19-graph-protein-design.

    Returns a `torch.Tensor` RBF embedding of `distances` along a new axis=-1.
    That is, if `distances` has shape `[..., dims]`, then the returned Tensor will have
    shape `[..., dims, num_rbf]`.
    """
    distance_mu = torch.linspace(
        min_distance, max_distance, num_rbf, device=distances.device
    )
    distance_mu = distance_mu.view([1, -1])
    distance_sigma = (max_distance - min_distance) / num_rbf
    distance_expanded = torch.unsqueeze(distances, -1)
    rbf = torch.exp(
        -(((distance_expanded - distance_mu) / distance_sigma) ** 2)
    )
    return rbf
